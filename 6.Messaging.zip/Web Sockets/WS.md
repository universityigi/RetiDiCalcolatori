Vedi [qui](http://websocket.org/)
