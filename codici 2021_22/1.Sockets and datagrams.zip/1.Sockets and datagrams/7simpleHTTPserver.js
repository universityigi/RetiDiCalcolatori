// https://www.codementor.io/@ziad-saab/let-s-code-a-web-server-from-scratch-with-nodejs-streams-h4uc9utji
fs = require('fs');
const net = require('net');
const server = net.createServer();
server.on('connection', handleConnection);
server.listen(3000);

function handleConnection(socket) {
 
  socket.on('data', (chunk) => {
    console.log('Received chunk:\n', chunk);
    console.log('chunk size: ', chunk.length);
    console.log('\n Received chunk:\n', chunk.toString());
    console.log('string size: ', chunk.toString().length);
    console.log("->"+chunk.toString()+"<-");
    console.log("->"+chunk[chunk.length-2]+"<-");
    console.log("->"+chunk[chunk.length-1]+"<-");
    console.log("\\r "+encodeURI('\r'));
    console.log("\\n "+encodeURI('\n'));

    if ((chunk[chunk.length-4]==13) && (chunk[chunk.length-3]==10) && (chunk[chunk.length-2]==13) && (chunk[chunk.length-1]==10)){
      socket.write('HTTP/1.1 200 OK\r\nServer: my-web-server\r\nContent-Length: 5\r\n\r\nhello\r\n\r\n');
    }
    
  });
  
  //socket.write('HTTP/1.1 200 OK\r\nServer: my-web-server\r\nContent-Length: 5\r\n\r\nhello\r\n\r\n');
}

// curl -v -I -H "Testing: Test header so you see this works" http://localhost:3000
// curl -v -I -H "Testing: Test header so you see this works" http://localhost:3000/page
// curl --header "Content-Type: application/json"   --request POST   --data '{"username":"xyz","password":"xyz"}' http://localhost:3000
