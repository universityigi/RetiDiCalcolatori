var net = require('net');

let hi = false;

// nc localhost 8081 --> \n
// nc -C localhost 8081 --> \r\n

console.log("attenti al terminatore!");
console.log("\\r "+encodeURI('\r'));
console.log("\\n "+encodeURI('\n'));

var server = net.createServer(function(socket) { 
   console.log('client connected');

   console.log(socket.address());
   console.log("-->",socket.remoteAddress,socket.remotePort);
   
   socket.on('end', function() {
      console.log('client disconnected');
   });
   
   socket.write('Hello \r\n');

   socket.on('data', function(data) {
    msg = data.toString();
    console.log("msg from client:"+encodeURI(msg), hi);

    if (msg==="Hi\r\n") {
    //if (msg==="Hi\n") {
        socket.write("Hi (from server)\r\n");
        console.log("status:"+1);
        hi = true;
    }
    else if (msg==="Got the time?\r\n" && hi===true){
    //else if (msg==="Got the time?\n" && hi===true){
      console.log("status:"+2);
      var d = new Date();
      var n = d.getHours();
      socket.write(n.toString()+"\r\n");
      hi = false;
    } else hi = false;
    
   });

   //socket.pipe(socket);
});

server.listen(8081, function() { 
   console.log('server is listening');
});




