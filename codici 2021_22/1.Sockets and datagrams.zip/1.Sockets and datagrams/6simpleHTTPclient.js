// https://hub.docker.com/_/nginx
// docker run --name some-nginx -d -p 8080:80 nginx
// docker run --name some-nginx -d -p 8080:80 -v /home/andrea/Documents/University/teaching/RC/2020/code/node/1.sockets\ and\ datagrams/some/content:/usr/share/nginx/html nginx

var net = require('net');

var client = new net.Socket();
client.connect(8080, '127.0.0.1', function() {
	console.log('Connected');
	client.write('GET / HTTP/1.6789\r\n');
	client.write('Host: www.example.com\r\n\r\n');
});

client.on('data', function(data) {
	console.log('Received: ' + data);
	client.destroy(); // kill client after server's response
});

client.on('close', function() {
	console.log('Connection closed');
});
