var request = require("request");
var userDetails;

function getData(url) {
    // Setting URL and headers for request
    var options = {
        url: url,
        headers: {
            'User-Agent': 'request'
        }
    };
    // Return new promise 
    return new Promise(function(resolve, reject) {
        // Do async job
        request.get(options, function(err, resp, body) {
            if (err) {
                reject(err);
            } else {
                resolve(body);
            }
        })
    })
}

var errHandler = function(err) {
    console.log(err);
}

function main() {
    var userProfileURL = "https://api.github.com/users/andreavitaletti";
    var dataPromise = getData(userProfileURL);
    // Get user details after that get followers from URL
    dataPromise.then(JSON.parse, errHandler)
               // By chaining then functions on a promise we can pass the data to the next functions
               // When a value is returned from then, the next then can get the value. 
               .then(function(result) {
                    userDetails = result;
                    console.log("Here I have the user details");
                    // Do one more async operation here
                    var anotherPromise = getData(userDetails.followers_url).then(JSON.parse);
                    // We can also return a promise from then so that the next chained then function 
                    // can use that to build its own logic.
                    return anotherPromise;
                }, errHandler) // end management first promise
                .then(function(data) {
                    console.log("---------------------------------------");
                    console.log(data);
                    console.log("---------------------------------------");
                }, errHandler); // end management second promise
}


main();
