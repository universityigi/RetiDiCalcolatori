// adapted from https://medium.com/dev-bits/writing-neat-asynchronous-node-js-code-with-promises-32ed3a4fd098

var request = require("request");
var userDetails;

function initialize() {
    // Setting URL and headers for request
    var options = {
        url: 'https://api.github.com/users/andreavitaletti',
        headers: {
            'User-Agent': 'request'
        }
    };
    // Return new promise 

    /* Essentially, a Promise is an object that represents an intermediate state of an operation — in effect, a promise that a result of some kind will be returned at some point in the future. There is no guarantee of exactly when the operation will complete and the result will be returned, but there is a guarantee that when the result is available, or the promise fails, the code you provide will be executed in order to do something else with a successful result, or to gracefully handle a failure case. */

    return new Promise(function(resolve, reject) {
    	// Do async job
        request.get(options, function(err, resp, body) {
            // A promise can either be resolved or rejected
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(body)); 
            }
        })
    })

}


function main() {
    var initializePromise = initialize(); // The reference to the promise 
    
    // The code which uses a promise should call then function on that promise. It takes two anonymous functions as 
    // parameters. The first function executes if the promise is resolved and the second function executes 
    // if promise is rejected.

    initializePromise.then(function(result) { // function to handle the resolve of the promise
        userDetails = result;
        console.log("Initialized user details");
        // Use user details from here
        console.log(userDetails)
    }, function(err) { // function to handle the reject of the promise
        console.log(err);
    })
}




main();
