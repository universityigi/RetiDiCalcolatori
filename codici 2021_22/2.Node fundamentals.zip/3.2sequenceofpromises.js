var message = "";

// note that the promises are immediately instantiated one after the other

promise1 = new Promise((resolve, reject) => {
    setTimeout(() => {
        message += "my";
        console.log("P1"+message);
        resolve(message);
    }, 2000)
})


promise2 = new Promise((resolve, reject) => {
    setTimeout(() => {
        message += " first";
        console.log("P2"+message);
        resolve(message);
    }, 2000)
})

promise3 = new Promise((resolve, reject) => {
    setTimeout(() => {
        message += " promise";
        console.log("P3"+message);
        resolve(message);
    }, 2000)
})

/*
promise1 = new Promise((resolve, reject) => {
    setTimeout(() => {
        message += "my";
        console.log("P1"+message);
        resolve(message);
    }, 2000)
})
*/

// having the same timeout interval, they will be executed sequentially

var printResult = (results) => {console.log("Results = ", results, "- message = ", message)}

function main() {
    // See the order of promises. Final result will be according to it
    // Promise.all([promise1, promise2, promise3]).then(printResult);
    // Promise.all([promise2, promise1, promise3]).then(printResult);
    // Promise.all([promise3, promise2, promise1]).then(printResult);
    //Promise.all([promise2]).then(printResult);
    //console.log("\"\"" + message);
    promise1.then(printResult);
}

main();
