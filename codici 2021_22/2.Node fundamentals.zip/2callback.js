// based on https://codeburst.io/javascript-what-the-heck-is-a-callback-aba4da2deced

/* 1 -----------------------------------------
function first(){
    console.log(1);
  }
function second(){
    console.log(2);
  }

first();
second();
*/

/* 2 ----------------------------------------- 
function first(){
    // Simulate a code delay
    setTimeout( function(){
      console.log(1);
    }, 500 );
  }

function second(){
    console.log(2);
  }

first();
second();
*/


/* 3 ----------------------------------------- */
function first(){
  // Simulate a code delay
  setTimeout( function(){
    console.log(1);
    second();
  }, 500 );
}

function second(){
  console.log(2);
}

first();
/**/


// How to define a callback function


/* 4 ----------------------------------------- */
/*
function doHomework(subject, callback) {
    console.log(`Starting my ${subject} homework.`);
    callback();
  }

  doHomework('math', function() {
    console.log('Finished my homework');
  });
*/

/* 5 ----------------------------------------- */
/*
function doHomework(subject, callback) {
    console.log(`Starting my ${subject} homework.`);
    {

      // fai un miliardo di cose che impiegano 10 anni;      
    }
    callback();
  }

function alertFinished(){
    console.log('Finished my homework');
  }

doHomework('math', alertFinished);

*/