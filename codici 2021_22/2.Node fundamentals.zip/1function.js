function first(msg){
    console.log(msg);
  }

// ARROW FUNCTIONS

first_new = (msg) => console.log(msg);

first("hello");
first_new("ciao");