# docker-nginx-node

## Usage

```
docker-compose up -d
```
