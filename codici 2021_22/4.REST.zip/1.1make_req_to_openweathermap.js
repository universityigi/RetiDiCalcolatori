//const util = require('util')
require('dotenv').config({ path: '/home/andrea/Documents/University/teaching/.env' })

// il file .env è così strutturato
//
// METEO_KEY=xxxxxxxxxxxxxxxxxxxxxxxxxxxxx
// GOOGLE_KEY=yyyyyyyyyyyyyyyyyyyyyyyyyyyyy


var request = require('request');

// http://api.openweathermap.org/data/2.5/weather?q=Rome&appid=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

var options = {
  url: 'http://api.openweathermap.org/data/2.5/weather?q=Roma,IT&appid='+process.env.METEO_KEY,
}

function callback(error, response, body) {
  if (!error && response.statusCode == 200) {
    var info = JSON.parse(body);
    console.log("###############################");
    console.log(info);
    console.log("###############################");
    console.log(info.coord);
    console.log("###############################");
    console.log(info.coord.lon);
    console.log("###############################");
    console.log(info.coord.lat);
    console.log("###############################");
    console.log("###############################");
    console.log(info.main);
    console.log("###############################");
    console.log(info.main.temp);

    // ********************************************************
    /*
    var options = {
      url: 'https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat='+info.coord.lat+'&lon='+info.coord.lon,
      headers: {
        'User-Agent': 'Nodejs test in class'
      }
    };

    function callback(error, response, body) {
      //do somethings
      console.log(body);
    }

    request(options, callback);
    */
    /*
    request('https://maps.googleapis.com/maps/api/place/nearbysearch/json?location='+info.coord.lat+','+info.coord.lon+'&radius=500&types=food&key=VtRRQ1fZbYnSHEPm6FbIFtES', function optionalCallback(err, httpResponse, body) {
      request(, function optionalCallback(err, httpResponse, body) {
        console.log(body);

     });
     */
    // https://nominatim.org/release-docs/develop/api/Overview/

    // https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=-34.44076&lon=-58.70521

    // https://nominatim.openstreetmap.org/search?q=135+pilkington+avenue,+birmingham&format=xml&polygon_geojson=1&addressdetails=1
    // https://nominatim.openstreetmap.org/search?q=135+pilkington+avenue,+birmingham&format=json&polygon_geojson=1&addressdetails=1
    // ********************************************************
  }
}

request.get(options, callback);
