define({
  "name": "example-basic",
  "version": "0.1.0",
  "description": "apiDoc basic example",
  "template": {
    "withCompare": false
  },
  "url": "http://localhost:8080",
  "sampleUrl": "http://localhost:8080",
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2022-03-11T09:46:10.716Z",
    "url": "https://apidocjs.com",
    "version": "0.26.0"
  }
});
